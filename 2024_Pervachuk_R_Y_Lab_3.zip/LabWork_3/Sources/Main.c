#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "Matrix.h"


SVector VectorInput(unsigned long int NumElement) {
    SVector v = VectorCreate(NumElement);

    printf("\nEnter %lu coordinates for the vector:\n", NumElement);

    for (unsigned long int i = 0; i < NumElement; i++) {
        char input[100];
        double value;
        printf("Coordinate %lu: ", i + 1);
        fgets(input, sizeof(input), stdin);
        if (sscanf_s(input, "%lf", &value) != 1) {
            printf("Invalid input. Please enter a number.\n");
            i--;
            continue;
        }
        v.Data[i] = value;
    }

    return v;
}


void InputVectorCoordinates(SVector* v) {
    unsigned long int numCoords = v->VectorSize;
    *v = VectorInput(numCoords);
}


void DisplayVectorCoordinates(SVector v) {
    VectorDisplay(v);
}


SVector GenerateVectorByFormula(unsigned long int NumElement, double (*formula)(unsigned long int)) {
    SVector v = VectorCreate(NumElement);

    for (unsigned long int i = 0; i < NumElement; i++)
        v.Data[i] = formula(i);

    return v;
}



double ExampleFormula(unsigned long int index) {
    return index * 2.0;
}


void MatrixInput(SMatrix* m) {
    unsigned long int row = m->Row;
    unsigned long int col = m->Col;

    for (unsigned long int i = 0; i < row; i++) {
        for (unsigned long int j = 0; j < col; j++) {
            char input[100];
            double value;
            printf("Enter element [%lu][%lu]: ", i, j);
            fgets(input, sizeof(input), stdin);
            if (sscanf_s(input, "%lf", &value) != 1) {
                printf("Invalid input. Please enter a number.\n");
                j--;
                continue;
            }
            m->Data[i][j] = value;
        }
    }
}


int main() {
    printf("Start!\n");

    SVector v1 = VectorCreate(3);
    InputVectorCoordinates(&v1);

    printf("\nFirst vector coordinates:");
    DisplayVectorCoordinates(v1);

    SVector v2 = VectorCreate(3);
    InputVectorCoordinates(&v2);

    printf("\nSecond vector coordinates:");
    DisplayVectorCoordinates(v2);

    printf("\nAdding vectors:");
    SVector sum = VectorAdd(v1, v2);
    printf("\nResult of addition:");
    VectorDisplay(sum);

    printf("\nSubtracting vectors:");
    SVector diff = VectorDiff(v1, v2);
    printf("\nResult of subtraction:");
    VectorDisplay(diff);

    printf("\nScalar product of vectors: %g\n", VectorScalar(v1, v2));

    SMatrix m1 = MatrixCreate(2, 3);
    printf("\nEnter elements for first matrix:\n");
    MatrixInput(&m1);

    printf("\nFirst matrix:");
    MatrixDisplay(m1);

    printf("\nMultiplying matrix by vector:");
    SMatrix result = MatrixMVMult(m1, v1);
    printf("\nResult of matrix-vector multiplication:");
    MatrixDisplay(result);

    SMatrix m2 = MatrixCreate(3, 2);
    printf("\nEnter elements for second matrix:\n");
    MatrixInput(&m2);

    printf("\nSecond matrix:");
    MatrixDisplay(m2);

    printf("\nMultiplying matrices:");
    SMatrix product = MatrixMMMult(m1, m2);
    printf("\nResult of matrix multiplication:");
    MatrixDisplay(product);
   
    VectorDelete(&v1);
    VectorDelete(&v2);
    VectorDelete(&sum);
    VectorDelete(&diff);
    MatrixDelete(&m1);
    MatrixDelete(&m2);
    MatrixDelete(&result);
    MatrixDelete(&product);

    printf("\nStopped!\n");
    return 0;
}
