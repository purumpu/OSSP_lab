#include <stdlib.h>
#include <stdio.h>
#include "Matrix.h"


SVector VectorCreate(unsigned long int NumElement)
{
	SVector v;
	v.VectorSize = NumElement;
	v.Data = calloc(NumElement, sizeof(double));
	if (v.Data == NULL) {
		fprintf(stderr, "Memory allocation failed\n");
		exit(EXIT_FAILURE);
	}
	return v;
}


void VectorDisplay(SVector v1)
{
	printf("\nvector[%lu]=", v1.VectorSize);
	for (unsigned long int i = 0; i < v1.VectorSize; i++)
		printf(" %g", v1.Data[i]);
}


SVector VectorAdd(SVector v1, SVector v2)
{
	if (v1.VectorSize != v2.VectorSize) {
		fprintf(stderr, "Vectors must be of the same size for addition\n");
		exit(EXIT_FAILURE);
	}
	SVector result = VectorCreate(v1.VectorSize);
	for (unsigned long int i = 0; i < v1.VectorSize; i++)
		result.Data[i] = v1.Data[i] + v2.Data[i];
	return result;
}


SVector VectorDiff(SVector v1, SVector v2)
{
	if (v1.VectorSize != v2.VectorSize)
	{
		fprintf(stderr, "Vectors must be of the same size for subtraction!\n");
		return VectorCreate(0);
	}

	SVector result = VectorCreate(v1.VectorSize);

	for (unsigned long int i = 0; i < v1.VectorSize; i++)
	{
		result.Data[i] = v1.Data[i] - v2.Data[i];
	}

	return result;
}


double VectorScalar(SVector v1, SVector v2)
{
	if (v1.VectorSize != v2.VectorSize)
	{
		fprintf(stderr, "Vectors must be of the same size for scalar product!\n");
		return 0.0;
	}

	double result = 0;

	for (unsigned long int i = 0; i < v1.VectorSize; i++)
	{
		result += v1.Data[i] * v2.Data[i];
	}

	return result;
}


SVector VectorMultConst(SVector v1, double c)
{
	SVector result = VectorCreate(v1.VectorSize);
	
	for (unsigned long int i = 0; i < v1.VectorSize; i++)
	{
		result.Data[i] = v1.Data[i] * c;
	}
	
	return result;
}


SVector VectorCopy(SVector v1)
{
	SVector result = VectorCreate(v1.VectorSize);
	
	for (unsigned long int i = 0; i < v1.VectorSize; i++)
	{
		result.Data[i] = v1.Data[i];
	}
	
	return result;
}


void VectorDelete(SVector* v1)
{
	free(v1->Data);
	v1->VectorSize = 0;
}


SMatrix MatrixCreate(unsigned long int row, unsigned long int col)
{
	SMatrix m;
	m.Row = row;
	m.Col = col;
	m.Data = (double**)calloc(row, sizeof(double*));
	if (m.Data == NULL) {
		fprintf(stderr, "Memory allocation failed\n");
		exit(EXIT_FAILURE);
	}
	for (unsigned long int i = 0; i < row; i++) {
		m.Data[i] = (double*)calloc(col, sizeof(double));
		if (m.Data[i] == NULL) {
			fprintf(stderr, "Memory allocation failed\n");
			exit(EXIT_FAILURE);
		}
	}
	return m;
}


void MatrixDisplay(SMatrix m1)
{
	printf("\nMatrix %lu x %lu:\n", m1.Row, m1.Col);
	
	for (unsigned long int i = 0; i < m1.Row; i++)
	{
		for (unsigned long int j = 0; j < m1.Col; j++)
			printf("%g\t", m1.Data[i][j]);
		printf("\n");
	}
}


void MatrixMakeE(SMatrix* m1)
{
	if (m1->Row != m1->Col)
	{
		fprintf(stderr, "Cannot make non-square matrix identity!\n");
		return;
	}

	for (unsigned long int i = 0; i < m1->Row; i++)
	{
		for (unsigned long int j = 0; j < m1->Col; j++)
		{
			m1->Data[i][j] = (i == j) ? 1.0 : 0.0;
		}
	}
}


SMatrix MatrixMMMult(SMatrix m1, SMatrix m2)
{
	if (m1.Col != m2.Row)
	{
		fprintf(stderr, "The dimensions of the matrix must be the same!\n");
		
		return MatrixCreate(0, 0);
	}

	SMatrix result = MatrixCreate(m1.Row, m2.Col);
	
	for (unsigned long int i = 0; i < m1.Row; i++)
	{
		for (unsigned long int j = 0; j < m2.Col; j++)
		{
			for (unsigned long int k = 0; k < m1.Col; k++)
				result.Data[i][j] += m1.Data[i][k] * m2.Data[k][j];
		}
	}

	return result;
}


SMatrix MatrixMMAdd(SMatrix m1, SMatrix m2)
{
	if (m1.Row != m2.Row || m1.Col != m2.Col)
	{
		fprintf(stderr, "The dimensions of the matrix must be the same!\n");
		
		return MatrixCreate(0, 0);
	}

	SMatrix result = MatrixCreate(m1.Row, m1.Col);
	
	for (unsigned long int i = 0; i < m1.Row; i++)
	{
		for (unsigned long int j = 0; j < m1.Col; j++)
			result.Data[i][j] = m1.Data[i][j] + m2.Data[i][j];
	}
	
	return result;
}


SMatrix MatrixMVMult(SMatrix m1, SVector v1)
{
	if (m1.Col != v1.VectorSize)
	{
		fprintf(stderr, "For multiplication, the size of the matrix and the vector must be the same!\n");
		
		return MatrixCreate(0, 0);
	}

	SMatrix result = MatrixCreate(m1.Row, 1);
	
	for (unsigned long int i = 0; i < m1.Row; i++)
	{
		for (unsigned long int j = 0; j < v1.VectorSize; j++)
			result.Data[i][0] += m1.Data[i][j] * v1.Data[j];
	}
	
	return result;
}


SMatrix MatrixCopy(SMatrix m1)
{
	SMatrix result = MatrixCreate(m1.Row, m1.Col);
	
	for (unsigned long int i = 0; i < m1.Row; i++)
	{
		for (unsigned long int j = 0; j < m1.Col; j++)
			result.Data[i][j] = m1.Data[i][j];
	}
	
	return result;
}


void MatrixDelete(SMatrix* m1)
{
	for (unsigned long int i = 0; i < m1->Row; i++)
		free(m1->Data[i]);
	
	free(m1->Data);
	m1->Row = 0;
	m1->Col = 0;
}